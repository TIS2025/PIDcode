//package org.firstinspires.ftc.teamcode.TeleOp;
//
//import com.acmerobotics.dashboard.config.Config;
//import com.acmerobotics.dashboard.FtcDashboard;
//
//import com.acmerobotics.roadrunner.Pose2d;
//import com.acmerobotics.roadrunner.PoseVelocity2d;
//import com.acmerobotics.roadrunner.Vector2d;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//
//import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
//import org.firstinspires.ftc.teamcode.Hardware.BotHardware;
//import org.firstinspires.ftc.teamcode.MecanumDrive;
//import org.firstinspires.ftc.teamcode.Subsystems.armPID;
//
//@Config
//@TeleOp(name = "Extension arm PID", group = "Teleop")
//public class PIDcode extends LinearOpMode {
//
//    public static BotHardware robot = BotHardware.getInstance();
//    private armPID arm;
//
//    @Override
//    public void runOpMode() {
//        // Init
//        robot.init(hardwareMap, telemetry);
//        arm = new armPID(robot);
//        MecanumDrive drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
//        FtcDashboard.getInstance();
//
//        telemetry.addLine("Custom PID with Dashboard Ready");
//        telemetry.update();
//
//        waitForStart();
//
//        telemetry.addLine("Started Loop");
//        telemetry.update();
//        sleep(1000);
//
//        robot.resetencoder();
//
//        while (opModeIsActive()) {
//
//            drive.setDrivePowers(
//                    new PoseVelocity2d(
//                            new Vector2d(
//                                    -gamepad1.left_stick_y,
//                                    -gamepad1.right_stick_x
//
//                            ),
//                            -gamepad1.left_stick_x
//
//                    )
//            );
//
//            drive.updatePoseEstimate();
//
//            // === Gamepad presets for arm ===
//            if (gamepad1.y) {             // Y: Extend + Pivot Up
//                arm.setPivotTarget(-1863);
//                arm.setExtensionTarget(1200);
//            }
//            if (gamepad1.x) {             // X: Retract + Pivot Down
//                arm.setPivotTarget(0);
//                arm.setExtensionTarget(0);
//            }
//            if (gamepad1.b) {             // B: Extend + Pivot Down
//                arm.setPivotTarget(0);
//                arm.setExtensionTarget(1200);
//            }
//            if (gamepad1.a) {             // A: Retract + Pivot Up
//                arm.setPivotTarget(-1863);
//                arm.setExtensionTarget(0);
//            }
//
//            // Run internal PID control
//            arm.update();
//
//            // Telemetry for tuning/debugging
//            telemetry.addLine("--------------- PIVOT ----------------");
//            telemetry.addData("Target", arm.pivotTarget);
//            telemetry.addData("Position", robot.pivot_motor.getCurrentPosition());
//            telemetry.addData("Pivot Motor Current : ", robot.pivot_motor.getCurrent(CurrentUnit.AMPS));
//
//            telemetry.addLine("--------------- EXTENSION --------------");
//            telemetry.addData("Target", arm.extensionTarget);
//            telemetry.addData("Position", robot.extension_motor.getCurrentPosition());
//            telemetry.addData("Extension Motor Current : ", robot.extension_motor.getCurrent(CurrentUnit.AMPS));
//
//            telemetry.addLine("--------------- PID VALUES -------------");
//            telemetry.addData("Pivot kP", arm.pivot_kP);
//            telemetry.addData("Pivot kI", arm.pivot_kI);
//            telemetry.addData("Pivot kD", arm.pivot_kD);
//            telemetry.addData("Ext kP", arm.ext_kP);
//            telemetry.addData("Ext kI", arm.ext_kI);
//            telemetry.addData("Ext kD", arm.ext_kD);
//            telemetry.update();
//        }
//    }
//}
//


/* ------------------------------------------ PID with Bulk Read --------------------------------------------------*/

package org.firstinspires.ftc.teamcode.TeleOp;

import static org.firstinspires.ftc.teamcode.TeleOp.PGFteleop.ftc;
import static org.firstinspires.ftc.teamcode.TeleOp.PGFteleop.updateAction;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.PoseVelocity2d;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.Vector2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Gamepad;

import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
import org.firstinspires.ftc.teamcode.Globals.globals;
import org.firstinspires.ftc.teamcode.Hardware.BotHardware;
import org.firstinspires.ftc.teamcode.MecanumDrive;
import org.firstinspires.ftc.teamcode.Subsystems.ArmPID;
import org.firstinspires.ftc.teamcode.Subsystems.ArmPIDUpdater;

import java.util.ArrayList;
import java.util.List;

@Config
@TeleOp(name = "PID Bulk Mode Compare", group = "Teleop")
public class PIDcode extends LinearOpMode {

    public static BotHardware robot = BotHardware.getInstance();
    private ArmPID arm;
    private MecanumDrive drive;
    public static boolean flipped = true;
    public static double strafe = 1, speed = 1, turn = 1;

    // Toggle bulk read & loop telemetry
    private boolean useBulk = true;
    private boolean showLoop = true;

    private final double TARGET_BULK_LOOP = 8.0;
    private final double TARGET_NO_BULK_LOOP = 12.0;
    private final double TARGET_BULK_NO_LOOP = 8.0;
    private final double TARGET_NO_BULK_NO_LOOP = 12.0;


    private enum BulkMode {
        BULK_LOOP,      // gamepad2.a
        NO_BULK_LOOP,   // gamepad2.b
        BULK_NO_LOOP,   // gamepad2.x
        NO_BULK_NO_LOOP // gamepad2.y
    }

    private BulkMode currentMode = BulkMode.BULK_LOOP;

    private double getTargetTimeMs(BulkMode mode) {
        switch (mode) {
            case BULK_LOOP: return TARGET_BULK_LOOP;
            case NO_BULK_LOOP: return TARGET_NO_BULK_LOOP;
            case BULK_NO_LOOP: return TARGET_BULK_NO_LOOP;
            case NO_BULK_NO_LOOP: return TARGET_NO_BULK_NO_LOOP;
            default: return 10.0;
        }
    }

    @Override
    public void runOpMode() {
        robot.init(hardwareMap, telemetry);
        arm = new ArmPID(robot);
        drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));

        Gamepad CG1 = new Gamepad(), CG2 = new Gamepad();
        Gamepad PG1 = new Gamepad(), PG2 = new Gamepad();

        while (opModeInInit()) {
            arm.setUseBulkClear(true);
            arm.updatePivotState(ArmPID.PivotState.INIT);
            arm.updateExtensionState(ArmPID.ExtensionState.INIT);
            arm.updateElbowState(ArmPID.ElbowState.INIT);
            arm.updateClawState(ArmPID.ClawState.INIT);
            arm.updateWristState(ArmPID.WristState.INIT);
            arm.update();

            telemetry.addData("Pivot", robot.pivot_motor.getCurrentPosition());
            telemetry.addData("Extension", robot.extension_motor.getCurrentPosition());
            telemetry.update();
        }

        waitForStart();
        robot.resetencoder();

        while (opModeIsActive()) {
            long startTime = System.nanoTime();

            PG1.copy(CG1);
            PG2.copy(CG2);
            CG1.copy(gamepad1);
            CG2.copy(gamepad2);

            // Toggle modes
            if (gamepad2.a) {
                useBulk = true;
                showLoop = true;
                currentMode = BulkMode.BULK_LOOP;
            } else if (gamepad2.b) {
                useBulk = false;
                showLoop = true;
                currentMode = BulkMode.NO_BULK_LOOP;
            } else if (gamepad2.x) {
                useBulk = true;
                showLoop = false;
                currentMode = BulkMode.BULK_NO_LOOP;
            } else if (gamepad2.y) {
                useBulk = false;
                showLoop = false;
                currentMode = BulkMode.NO_BULK_NO_LOOP;
            }

            arm.setUseBulkClear(useBulk);
            arm.update();

            ftc = updateAction();
            ftc.add(new ArmPIDUpdater(arm));

            // Drive
            drive.setDrivePowers(
                    new PoseVelocity2d(
                            new Vector2d(gamepad1.left_stick_y, gamepad1.left_stick_x),
                            gamepad1.right_stick_x / 2)
            );
            if (gamepad1.left_trigger > 0.3) {
                drive.setDrivePowers(
                        new PoseVelocity2d(
                                new Vector2d(gamepad1.left_stick_y / 2, gamepad1.left_stick_x / 2),
                                gamepad1.right_stick_x / 3)
                );
            }

            // === Arm Presets ===
            if (gamepad1.right_bumper) {
                ftc.add(new ParallelAction(
                        new ArmPIDUpdater(arm),
                        new SequentialAction(
                                new InstantAction(() -> arm.setPivotTarget(-150)),
                                new SleepAction(0.5),
                                new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.SAMPLE_PICK)),
                                new SleepAction(1),
                                new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INTAKE)),
                                new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_PICK)),
                                new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.OPEN)),
                                new SleepAction(0.1)
                        )
                ));
            }

            if (gamepad1.b) {
                ftc.add(new ParallelAction(
                        new ArmPIDUpdater(arm),
                        new SequentialAction(
                                new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PICK)),
                                new SleepAction(0.5),
                                new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.CLOSE)),
                                new SleepAction(1),
                                new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PRE_PICK)),
                                new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_DROP)),
                                new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INIT)),
                                new SleepAction(0.5),
                                new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT))
                        )
                ));
            }

            if (gamepad1.a) {
                ftc.add(new ParallelAction(
                        new ArmPIDUpdater(arm),
                        new SequentialAction(
                                new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.CLOSE)),
                                new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_DROP)),
                                new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INIT)),
                                new SleepAction(0.5),
                                new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT)),
                                new InstantAction(() -> arm.setPivotTarget(-1600))
                        )
                ));
            }

            if (gamepad1.y) {
                ftc.add(new SequentialAction(
                        new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INIT)),
                        new SleepAction(0.5),
                        new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT)),
                        new InstantAction(() -> arm.setPivotTarget(-1600)),
                        new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.SAMPLE_DROP)),
                        new SleepAction(1.5),
                        new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.BASKET_DROP)),
                        new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_DROP)),
                        new SleepAction(0.5),
                        new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.OPEN)),
                        new SleepAction(1),
                        new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_PICK)),
                        new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INTAKE)),
                        new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT)),
                        new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PRE_PICK))
                ));
            }

            if (gamepad1.x) {
                ftc.add(new ParallelAction(
                        new ArmPIDUpdater(arm),
                        new SequentialAction(
                                new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.OPEN)),
                                new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_PICK)),
                                new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INIT)),
                                new SleepAction(0.5),
                                new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT)),
                                new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PRE_PICK))
                        )
                ));
            }

            // Wrist toggle
            if (gamepad1.dpad_down) {
                if (flipped) {
                    ftc.add(new SequentialAction(
                            new InstantAction(() -> robot.Wrist.setPosition(globals.Wrist0)),
                            new InstantAction(() -> robot.Claw.setPosition(globals.ClawOpen)),
                            new SleepAction(0.1),
                            new InstantAction(() -> flipped = false)
                    ));
                } else {
                    ftc.add(new SequentialAction(
                            new InstantAction(() -> robot.Wrist.setPosition(globals.Wrist90)),
                            new InstantAction(() -> robot.Claw.setPosition(globals.ClawOpen)),
                            new SleepAction(0.1),
                            new InstantAction(() -> flipped = true)
                    ));
                }
            }

            // === Telemetry ===
            telemetry.addLine("======= MODE CONFIG =======");
            telemetry.addData("Mode", currentMode);
            telemetry.addData("Bulk Clear Enabled", useBulk);
            telemetry.addData("Show Loop Time", showLoop);

            telemetry.addLine("======= ARM PID =======");
            telemetry.addData("Pivot Target", ArmPID.pivotTarget);
            telemetry.addData("Pivot Pos", robot.pivot_motor.getCurrentPosition());
            telemetry.addData("Pivot Error", ArmPID.pivotTarget - robot.pivot_motor.getCurrentPosition());
            telemetry.addData("Ext Target", ArmPID.extensionTarget);
            telemetry.addData("Ext Pos", robot.extension_motor.getCurrentPosition());
            telemetry.addData("Ext Error", ArmPID.extensionTarget - robot.extension_motor.getCurrentPosition());

            telemetry.addLine("======= POWER & CURRENT =======");
            telemetry.addData("Pivot Power", robot.pivot_motor.getPower());
            telemetry.addData("Ext Power", robot.extension_motor.getPower());
            telemetry.addData("Pivot Current (A)", robot.pivot_motor.getCurrent(CurrentUnit.AMPS));
            telemetry.addData("Ext Current (A)", robot.extension_motor.getCurrent(CurrentUnit.AMPS));

            if (showLoop) {
                long endTime = System.nanoTime();
                double loopTimeMs = (endTime - startTime) / 1e6;

                double expectedTime = getTargetTimeMs(currentMode);

                telemetry.addData("Expected Loop Time (ms)", expectedTime);
                telemetry.addData("Actual Loop Time (ms)", String.format("%.2f", loopTimeMs));
                telemetry.addData("ArmPID Update Time (ms)", String.format("%.2f", arm.getLoopTimeMs()));
                telemetry.addData("Delta (Actual - Expected)", String.format("%.2f", loopTimeMs - expectedTime));
            }


            telemetry.update();

        }
    }
}

/*------------------------------------------ Voltage based PID + Bulk Read ----------------------------------------- */

//package org.firstinspires.ftc.teamcode.TeleOp;
//
//import static org.firstinspires.ftc.teamcode.TeleOp.PGFteleop.ftc;
//import static org.firstinspires.ftc.teamcode.TeleOp.PGFteleop.updateAction;
//
//import androidx.annotation.NonNull;
//
//import com.acmerobotics.dashboard.config.Config;
//import com.acmerobotics.roadrunner.Action;
//import com.acmerobotics.roadrunner.InstantAction;
//import com.acmerobotics.roadrunner.ParallelAction;
//import com.acmerobotics.roadrunner.Pose2d;
//import com.acmerobotics.roadrunner.PoseVelocity2d;
//import com.acmerobotics.roadrunner.SequentialAction;
//import com.acmerobotics.roadrunner.SleepAction;
//import com.acmerobotics.roadrunner.Vector2d;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.Gamepad;
//
//import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
//import org.firstinspires.ftc.teamcode.Globals.globals;
//import org.firstinspires.ftc.teamcode.Hardware.BotHardware;
//import org.firstinspires.ftc.teamcode.MecanumDrive;
//import org.firstinspires.ftc.teamcode.Subsystems.ArmPID;
//import org.firstinspires.ftc.teamcode.Subsystems.ArmPIDUpdater;
//
//@Config
//@TeleOp(name = "PID Bulk Mode Compare", group = "Teleop")
//public class PIDcode extends LinearOpMode {
//
//    public static BotHardware robot = BotHardware.getInstance();
//    private ArmPID arm;
//    private MecanumDrive drive;
//    public static boolean flipped = true;
//    public static double strafe = 1, speed = 1, turn = 1;
//
//    private boolean useBulk = true;
//    private boolean showLoop = true;
//
//    private final double TARGET_BULK_LOOP = 8.0;
//    private final double TARGET_NO_BULK_LOOP = 12.0;
//    private final double TARGET_BULK_NO_LOOP = 8.0;
//    private final double TARGET_NO_BULK_NO_LOOP = 12.0;
//
//    private enum BulkMode {
//        BULK_LOOP,
//        NO_BULK_LOOP,
//        BULK_NO_LOOP,
//        NO_BULK_NO_LOOP
//    }
//
//    private BulkMode currentMode = BulkMode.BULK_LOOP;
//
//    private double getTargetTimeMs(BulkMode mode) {
//        switch (mode) {
//            case BULK_LOOP: return TARGET_BULK_LOOP;
//            case NO_BULK_LOOP: return TARGET_NO_BULK_LOOP;
//            case BULK_NO_LOOP: return TARGET_BULK_NO_LOOP;
//            case NO_BULK_NO_LOOP: return TARGET_NO_BULK_NO_LOOP;
//            default: return 10.0;
//        }
//    }
//
//    @Override
//    public void runOpMode() {
//        robot.init(hardwareMap, telemetry);
//        arm = new ArmPID(robot);
//        drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
//
//        Gamepad CG1 = new Gamepad(), CG2 = new Gamepad();
//        Gamepad PG1 = new Gamepad(), PG2 = new Gamepad();
//
//        while (opModeInInit()) {
//            arm.setUseBulkRead(true);
//            arm.updatePivotState(ArmPID.PivotState.INIT);
//            arm.updateExtensionState(ArmPID.ExtensionState.INIT);
//            arm.updateElbowState(ArmPID.ElbowState.INIT);
//            arm.updateClawState(ArmPID.ClawState.INIT);
//            arm.updateWristState(ArmPID.WristState.INIT);
//            arm.update();
//
//            telemetry.addData("Pivot", robot.pivot_motor.getCurrentPosition());
//            telemetry.addData("Extension", robot.extension_motor.getCurrentPosition());
//            telemetry.update();
//        }
//
//        waitForStart();
//        robot.resetencoder();
//
//        while (opModeIsActive()) {
//            long startTime = System.nanoTime();
//
//            PG1.copy(CG1); PG2.copy(CG2);
//            CG1.copy(gamepad1); CG2.copy(gamepad2);
//
//            if (gamepad2.a) {
//                useBulk = true; showLoop = true; currentMode = BulkMode.BULK_LOOP;
//            } else if (gamepad2.b) {
//                useBulk = false; showLoop = true; currentMode = BulkMode.NO_BULK_LOOP;
//            } else if (gamepad2.x) {
//                useBulk = true; showLoop = false; currentMode = BulkMode.BULK_NO_LOOP;
//            } else if (gamepad2.y) {
//                useBulk = false; showLoop = false; currentMode = BulkMode.NO_BULK_NO_LOOP;
//            }
//
//            arm.setUseBulkRead(useBulk);  // updated from setUseBulkClear()
//            arm.update(); // still keep this in case
//
//            ftc = updateAction();
//            ftc.add(new ArmPIDUpdater(arm));
//
//            // Drive
//            drive.setDrivePowers(
//                    new PoseVelocity2d(
//                            new Vector2d(gamepad1.left_stick_y, gamepad1.left_stick_x),
//                            gamepad1.right_stick_x / 2)
//            );
//            if (gamepad1.left_trigger > 0.3) {
//                drive.setDrivePowers(
//                        new PoseVelocity2d(
//                                new Vector2d(gamepad1.left_stick_y / 2, gamepad1.left_stick_x / 2),
//                                gamepad1.right_stick_x / 3)
//                );
//            }
//
//            // === Arm Presets ===
//            if (gamepad1.right_bumper) {
//                ftc.add(new ParallelAction(
//                        new ArmPIDUpdater(arm),
//                        new SequentialAction(
//                                new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PRE_PICK)),
//                                new SleepAction(0.5),
//                                new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.SAMPLE_PICK)),
//                                new SleepAction(1),
//                                new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INTAKE)),
//                                new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_PICK)),
//                                new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.OPEN)),
//                                new SleepAction(0.1)
//                        )
//                ));
//            }
//
//            if (gamepad1.b) {
//                ftc.add(new ParallelAction(
//                        new ArmPIDUpdater(arm),
//                        new SequentialAction(
//                                new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PICK)),
//                                new SleepAction(0.5),
//                                new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.CLOSE)),
//                                new SleepAction(1),
//                                new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PRE_PICK)),
//                                new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_DROP)),
//                                new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INIT)),
//                                new SleepAction(0.5),
//                                new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT))
//                        )
//                ));
//            }
//
//            if (gamepad1.a) {
//                ftc.add(new ParallelAction(
//                        new ArmPIDUpdater(arm),
//                        new SequentialAction(
//                                new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.CLOSE)),
//                                new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_DROP)),
//                                new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INIT)),
//                                new SleepAction(0.5),
//                                new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT)),
//                                new InstantAction(() -> arm.setPivotTarget(-1600))
//                        )
//                ));
//            }
//
//            if (gamepad1.y) {
//                ftc.add(new SequentialAction(
//                        new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INIT)),
//                        new SleepAction(0.5),
//                        new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT)),
//                        new InstantAction(() -> arm.setPivotTarget(-1600)),
//                        new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.SAMPLE_DROP)),
//                        new SleepAction(1.5),
//                        new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.BASKET_DROP)),
//                        new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_DROP)),
//                        new SleepAction(0.5),
//                        new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.OPEN)),
//                        new SleepAction(1),
//                        new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_PICK)),
//                        new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INTAKE)),
//                        new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT)),
//                        new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PRE_PICK))
//                ));
//            }
//
//            if (gamepad1.x) {
//                ftc.add(new ParallelAction(
//                        new ArmPIDUpdater(arm),
//                        new SequentialAction(
//                                new InstantAction(() -> arm.updateClawState(ArmPID.ClawState.OPEN)),
//                                new InstantAction(() -> arm.updateWristState(ArmPID.WristState.SAMPLE_PICK)),
//                                new InstantAction(() -> arm.updateElbowState(ArmPID.ElbowState.INIT)),
//                                new SleepAction(0.5),
//                                new InstantAction(() -> arm.updateExtensionState(ArmPID.ExtensionState.INIT)),
//                                new InstantAction(() -> arm.updatePivotState(ArmPID.PivotState.SAMPLE_PRE_PICK))
//                        )
//                ));
//            }
//
//            // Wrist toggle
//            if (gamepad1.dpad_down) {
//                if (flipped) {
//                    ftc.add(new SequentialAction(
//                            new InstantAction(() -> robot.Wrist.setPosition(globals.Wrist0)),
//                            new InstantAction(() -> robot.Claw.setPosition(globals.ClawOpen)),
//                            new SleepAction(0.1),
//                            new InstantAction(() -> flipped = false)
//                    ));
//                } else {
//                    ftc.add(new SequentialAction(
//                            new InstantAction(() -> robot.Wrist.setPosition(globals.Wrist90)),
//                            new InstantAction(() -> robot.Claw.setPosition(globals.ClawOpen)),
//                            new SleepAction(0.1),
//                            new InstantAction(() -> flipped = true)
//                    ));
//                }
//            }
//            // === Preset Commands (unchanged) ===
//            // ... [All preset blocks remain as is; no changes needed]
//
//            // === Telemetry ===
//            telemetry.addLine("======= MODE CONFIG =======");
//            telemetry.addData("Mode", currentMode);
//            telemetry.addData("Bulk Clear Enabled", useBulk);
//            telemetry.addData("Show Loop Time", showLoop);
//
//            telemetry.addLine("======= ARM PID =======");
//            telemetry.addData("Pivot Target", ArmPID.pivotTarget);
//            telemetry.addData("Pivot Pos", robot.pivot_motor.getCurrentPosition());
//            telemetry.addData("Pivot Error", ArmPID.pivotTarget - robot.pivot_motor.getCurrentPosition());
//            telemetry.addData("Ext Target", ArmPID.extensionTarget);
//            telemetry.addData("Ext Pos", robot.extension_motor.getCurrentPosition());
//            telemetry.addData("Ext Error", ArmPID.extensionTarget - robot.extension_motor.getCurrentPosition());
//
//            telemetry.addLine("======= POWER & CURRENT =======");
//            telemetry.addData("Pivot Power", robot.pivot_motor.getPower());
//            telemetry.addData("Ext Power", robot.extension_motor.getPower());
//            telemetry.addData("Pivot Current (A)", robot.pivot_motor.getCurrent(CurrentUnit.AMPS));
//            telemetry.addData("Ext Current (A)", robot.extension_motor.getCurrent(CurrentUnit.AMPS));
//
//            if (showLoop) {
//                long endTime = System.nanoTime();
//                double loopTimeMs = (endTime - startTime) / 1e6;
//                double expectedTime = getTargetTimeMs(currentMode);
//
//                telemetry.addData("Expected Loop Time (ms)", expectedTime);
//                telemetry.addData("Actual Loop Time (ms)", String.format("%.2f", loopTimeMs));
//                telemetry.addData("Delta (Actual - Expected)", String.format("%.2f", loopTimeMs - expectedTime));
//            }
//
//            telemetry.update();
//        }
//    }
//}
