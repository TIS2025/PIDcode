//package com.example.meepmeeptesting;
//
//import com.acmerobotics.roadrunner.Pose2d;
//import com.acmerobotics.roadrunner.Vector2d;
//import com.noahbres.meepmeep.MeepMeep;
//import com.noahbres.meepmeep.roadrunner.DefaultBotBuilder;
//import com.noahbres.meepmeep.roadrunner.entity.RoadRunnerBotEntity;
//
//public class MeepMeepTestingSpecimen {
//    public static void main(String[] args) {
//        MeepMeep meepMeep = new MeepMeep(500);
//        Pose2d startPose = new Pose2d(15, -62, Math.toRadians(90));
//
//
//        RoadRunnerBotEntity myBot = new DefaultBotBuilder(meepMeep)
//                // Set bot constraints: maxVel, maxAccel, maxAngVel, maxAngAccel, track width
//                .setConstraints(60, 60, Math.toRadians(180), Math.toRadians(180), 15)
//                .build();
//
//
//        myBot.runAction(myBot.getDrive().actionBuilder(startPose)
//
////TODO ==================================================== Auto Specimen Path ======================================================
//
//            //pre load drop
//            .strafeToLinearHeading(new Vector2d(10, -35), Math.toRadians(105))
//            .waitSeconds(1)
//
//            //first pick
//            .strafeToLinearHeading(new Vector2d(40, -34), Math.toRadians(45))
//            .waitSeconds(1)
//            .strafeToLinearHeading(new Vector2d(40, -57), Math.toRadians(-45))
//            .waitSeconds(0.5)
//
//            //second pick
//            .strafeToLinearHeading(new Vector2d(60, -34), Math.toRadians(45))
//            .waitSeconds(1)
//            .strafeToLinearHeading(new Vector2d(60, -57), Math.toRadians(200))
//            .waitSeconds(0.5)
//
//            //third pick
//            .strafeToLinearHeading(new Vector2d(58, -34), Math.toRadians(90))
//            .waitSeconds(1)
//            .strafeToLinearHeading(new Vector2d(58, -57), Math.toRadians(200))
//            .waitSeconds(0.5)
//
//            //first drop
//            .strafeToLinearHeading(new Vector2d(37.31, -57), Math.toRadians(90))
//            .waitSeconds(0.5)
//            .strafeToLinearHeading(new Vector2d(15, -35), Math.toRadians(105))
//            .waitSeconds(0.5)
//            .strafeToLinearHeading(new Vector2d(37.31, -57), Math.toRadians(90))
//            .waitSeconds(1)
//
//            //second drop
//            .strafeToLinearHeading(new Vector2d(13, -35), Math.toRadians(105))
//            .waitSeconds(0.5)
//            .strafeToLinearHeading(new Vector2d(37.31, -59), Math.toRadians(90))
//            .waitSeconds(1)
//
//            //third drop
//            .strafeToLinearHeading(new Vector2d(10, -35), Math.toRadians(105))
//            .waitSeconds(0.5)
//            .strafeToLinearHeading(new Vector2d(37.31, -59), Math.toRadians(90))
//            //.splineToLinearHeading(new Pose2d(-18, -10, 0), Math.toRadians(0))
//
//            .build());
//
//        meepMeep.setBackground(MeepMeep.Background.FIELD_INTO_THE_DEEP_JUICE_DARK)
//                .setDarkMode(true)
//                .setBackgroundAlpha(0.95f)
//                .addEntity(myBot)
//                .start();
//    }
//}




package com.example.meepmeeptesting;

import com.acmerobotics.roadrunner.Pose2d;
import com.noahbres.meepmeep.MeepMeep;
import com.noahbres.meepmeep.roadrunner.DefaultBotBuilder;
import com.noahbres.meepmeep.roadrunner.entity.RoadRunnerBotEntity;

public class MeepMeepTestingSpecimen {
    public static void main(String[] args) {
        MeepMeep meepMeep = new MeepMeep(600);
//        Pose2d startPose = new Pose2d(-48, -45, Math.toRadians(45));
        Pose2d startPose = new Pose2d(-37.31, -57, Math.toRadians(0));

        RoadRunnerBotEntity myBot = new DefaultBotBuilder(meepMeep)
                // Set bot constraints: maxVel, maxAccel, maxAngVel, maxAngAccel, track width
                .setConstraints(60, 50, Math.toRadians(180), Math.toRadians(0), 9.5)
                .build();

        myBot.runAction(myBot.getDrive().actionBuilder(startPose)


                .setTangent(Math.toRadians(40))
                .splineToLinearHeading(new Pose2d(-30, -10,Math.toRadians(0)),Math.toRadians(0))  // First sample LL


                .setReversed(true)
                .splineToLinearHeading(new Pose2d(-55, -40,Math.toRadians(45)),Math.toRadians(-135)) // Drop first LL
                .waitSeconds(1)


//                .setTangent(Math.toRadians(40))
//                .splineToLinearHeading(new Pose2d(-30, -10,Math.toRadians(0)),Math.toRadians(0)) // Second sample LL
//
//
//                .setReversed(true)
//                .splineToLinearHeading(new Pose2d(-55, -40,Math.toRadians(45)),Math.toRadians(-135)) // Drop 2nd LL
//                .waitSeconds(1)
//
//                .setTangent(Math.toRadians(40))
//                .splineToLinearHeading(new Pose2d(-30, -10,Math.toRadians(0)),Math.toRadians(0)) // Third sample LL
//
//
//                .setReversed(true)
//                .splineToLinearHeading(new Pose2d(-55, -40,Math.toRadians(45)),Math.toRadians(-135)) // Drop 3rd LL
//                .waitSeconds(1)
//

                .build());


        meepMeep.setBackground(MeepMeep.Background.FIELD_INTO_THE_DEEP_JUICE_DARK)
                .setDarkMode(true)
                .setBackgroundAlpha(0.95f)
                .addEntity(myBot)
                .start();
    }
}
