package com.example.meepmeeptesting;

import com.acmerobotics.roadrunner.Pose2d;
import com.noahbres.meepmeep.MeepMeep;
import com.noahbres.meepmeep.roadrunner.DefaultBotBuilder;
import com.noahbres.meepmeep.roadrunner.entity.RoadRunnerBotEntity;

public class MeepMeepTestingCode {
    public static void main(String[] args) {
        MeepMeep meepMeep = new MeepMeep(600);
//        Pose2d startPose = new Pose2d(-48, -45, Math.toRadians(45));
        Pose2d startPose = new Pose2d(-37.31, -57, Math.toRadians(0));

        RoadRunnerBotEntity myBot = new DefaultBotBuilder(meepMeep)
                // Set bot constraints: maxVel, maxAccel, maxAngVel, maxAngAccel, track width
                .setConstraints(60, 50, Math.toRadians(180), Math.toRadians(0), 9.5)
                .build();

        myBot.runAction(myBot.getDrive().actionBuilder(startPose)


                .setTangent(Math.toRadians(40))
                .splineToLinearHeading(new Pose2d(-30, -10,Math.toRadians(0)),Math.toRadians(0))  // First sample LL


                .setReversed(true)
                .splineToLinearHeading(new Pose2d(-55, -40,Math.toRadians(45)),Math.toRadians(-135)) // Drop first LL
                .waitSeconds(1)


                .setTangent(Math.toRadians(40))
                .splineToLinearHeading(new Pose2d(-30, -10,Math.toRadians(0)),Math.toRadians(0)) // Second sample LL


                .setReversed(true)
                .splineToLinearHeading(new Pose2d(-55, -40,Math.toRadians(45)),Math.toRadians(-135)) // Drop 2nd LL
                .waitSeconds(1)

                .setTangent(Math.toRadians(40))
                .splineToLinearHeading(new Pose2d(-30, -10,Math.toRadians(0)),Math.toRadians(0)) // Third sample LL


                .setReversed(true)
                .splineToLinearHeading(new Pose2d(-55, -40,Math.toRadians(45)),Math.toRadians(-135)) // Drop 3rd LL
                .waitSeconds(1)


                .build());


        meepMeep.setBackground(MeepMeep.Background.FIELD_INTO_THE_DEEP_JUICE_DARK)
                .setDarkMode(true)
                .setBackgroundAlpha(0.95f)
                .addEntity(myBot)
                .start();
    }
}
