package org.firstinspires.ftc.teamcode.Subsystems;

import androidx.annotation.NonNull;

import com.arcrobotics.ftclib.controller.PIDFController;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.teamcode.Globals.Globals;
import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;

public class LifterPId {
    private final RobotHardware robot;

    PIDFController controller;

    public static double kp = 0.02;
    public static double ki = 0;
    public static double kd = 0;
    public static double kf = 0;



    public static int targetPosition=0;


    public LifterPId(RobotHardware  robot){
//        robot.LifterLeft1.setDirection(DcMotorSimple.Direction.REVERSE);
        controller = new PIDFController(kp,ki,kd,kf);
        this.robot = robot;
    }

    public enum LifterState{
        INIT,
        HOME,
        INTAKE,
        SPECIMEN_DROP,
        SAMPLE_DROP
    }

    public LifterState Lifterstate = LifterState.INIT;

    public void updateLifterState(@NonNull LifterState state){
        switch(state) {
            case HOME:
                targetPosition = Globals.LifterHome;
                break;

            case SPECIMEN_DROP:
                targetPosition = Globals.LifterSpecimenDrop;
                break;

            case INTAKE:
                targetPosition = Globals.LifterSamplePick;
                break;

            case SAMPLE_DROP:
                targetPosition = Globals.LifterSampleDrop;
                break;

        }this.Lifterstate = state;
    }

    //Call this method inside loop
    public void LIfterPid(){
        controller.setPIDF(kp,ki,kd,kf);
        double error=controller.calculate(robot.LifterLeft1.getCurrentPosition(),targetPosition);
        robot.LifterLeft1.setPower(error);
        robot.lifterRight.setPower(error);
        robot.LifterLeft2.setPower(error);
    }
}