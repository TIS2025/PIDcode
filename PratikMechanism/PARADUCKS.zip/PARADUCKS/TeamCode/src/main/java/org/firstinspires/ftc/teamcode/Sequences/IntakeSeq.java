package org.firstinspires.ftc.teamcode.Sequences;

import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;

import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;
import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;

public class IntakeSeq {
    public static RobotHardware robot = RobotHardware.getInstance();

    public static Action Home(Arm arm, LifterPId LifterPID) {
        return new ParallelAction(
                new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.HOME)),
                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.HOME)),
                new InstantAction(() -> arm.updateWristState(Arm.WristState.WRIST0)),
                new InstantAction(() -> arm.updateClawState(Arm.ClawState.CLOSE)),
                new InstantAction(() -> arm.updateSliderState(Arm.SliderState.HOME)),
                new InstantAction(() -> arm.updateSliderExtendState(Arm.SliderExtendState.HOME)),
                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.HOME))
        );
    }

    public static Action PreSampleIntake(Arm arm, LifterPId LifterPID) {
        return new SequentialAction(
                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.HOME)),
                new InstantAction(() -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_PICK)),
                new InstantAction(() -> arm.updateSliderState(Arm.SliderState.SLIDER_SAMPLE_PRE_PICK)),
                new InstantAction(() -> robot.Shoulder.setPosition(0.60)),
                new InstantAction(() -> arm.updateClawState(Arm.ClawState.OPEN)),
                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.INTAKE))
                //  new InstantAction(() -> arm.updateWristState(Arm.WristState.SAMPLE_PICK))
        );
    }


//    public static Action SampleIntake(Arm arm, LifterPId LifterPID) {
//        return new SequentialAction(
//                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.HOME)),
//                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.INTAKE)),
//                new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.INTAKE)),
//                new InstantAction(() -> arm.updateWristState(Arm.WristState.SAMPLE_PICK)),
//                new InstantAction(() -> arm.updateSliderState(Arm.SliderState.SLIDER_SAMPLE_PICK)),
//                new InstantAction(() -> arm.updateClawState(Arm.ClawState.CLOSE)),
//                new SleepAction(0.2)
//        );
//    }
//}

public static Action SampleIntake(Arm arm, LifterPId LifterPID) {
    return new SequentialAction(
            new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.INTAKE)),
            new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.BASKET_DROP)),
            // new InstantAction(() -> arm.updateWristState(Arm.WristState.SAMPLE_DROP)),
            new SleepAction(0.15),
            new InstantAction(() -> arm.updateClawState(Arm.ClawState.CLOSE)),
            new SleepAction(0.2),
            new InstantAction(() -> robot.Shoulder.setPosition(0.60))

    );
}
}