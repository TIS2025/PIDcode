//package org.firstinspires.ftc.teamcode.Auto;
//
//import com.acmerobotics.roadrunner.Action;
//import com.acmerobotics.roadrunner.InstantAction;
//import com.acmerobotics.roadrunner.Pose2d;
//import com.acmerobotics.roadrunner.SequentialAction;
//import com.acmerobotics.roadrunner.SleepAction;
//import com.acmerobotics.roadrunner.Vector2d;
//import com.acmerobotics.roadrunner.ftc.Actions;
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//
//import org.firstinspires.ftc.teamcode.Globals.Globals;
//import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;
//import org.firstinspires.ftc.teamcode.MecanumDrive;
//import org.firstinspires.ftc.teamcode.Sequences.AutoSampleDrop;
//import org.firstinspires.ftc.teamcode.Sequences.AutoSamplePick;
//import org.firstinspires.ftc.teamcode.Sequences.InitSeq;
//import org.firstinspires.ftc.teamcode.Subsystems.Arm;
//import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;
//
//@Autonomous(name = "AutoSampleSide", group = "Autonomous")
//public class AutoSampleCode extends LinearOpMode {
//    private final RobotHardware robot = RobotHardware.getInstance();
//    private MecanumDrive drive=null;
//    private Arm arm;
//    private LifterPId lifterPId;
//    public Pose2d initialPose = new Pose2d(-44, -60, Math.toRadians(90));
//
//    @Override
//    public void runOpMode() throws InterruptedException {
//
//        robot.init(hardwareMap, telemetry);
//        arm = new Arm(robot);
//        lifterPId = new LifterPId(robot);
//
//
//        drive = new MecanumDrive(hardwareMap, initialPose);
//
//        Action trajectoryAction0 = drive.actionBuilder(initialPose)
//
//                //PreLoad Sample Drop
////              .strafeToLinearHeading(new Vector2d(-58, -53), Math.toRadians(230))
//                .strafeToLinearHeading(new Vector2d(-48, -53), Math.toRadians(90))
////                .stopAndAdd(() -> new AutoSampleDrop(arm, lifterPId))
//                .afterTime(0.2, () -> lifterPId.updateLifterState(LifterPId.LifterState.HOME))
////
////                //First Sample Pick
////                .afterTime(0.8, () -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_PICK))
////                .strafeToLinearHeading(new Vector2d(-49.5, -43), Math.toRadians(90))
////                .waitSeconds(0.3)
////                .stopAndAdd(() -> new AutoSamplePick(arm, lifterPId))
////
////                //First Sample Drop
////                .strafeToLinearHeading(new Vector2d(-58, -53), Math.toRadians(45))
////                .stopAndAdd(() -> new AutoSampleDrop(arm, lifterPId))
////                .afterTime(0.2, () -> lifterPId.updateLifterState(LifterPId.LifterState.HOME))
////
////                //Second sample Pick
////                .afterTime(0.8, () -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_PICK))
////                .strafeToLinearHeading(new Vector2d(-51, -43), Math.toRadians(90))
////                .waitSeconds(0.3)
////                .stopAndAdd(() -> new AutoSamplePick(arm, lifterPId))
////
////                //Second Sample Drop
////                .strafeToLinearHeading(new Vector2d(-58, -53), Math.toRadians(45))
////                .stopAndAdd(() -> new AutoSampleDrop(arm, lifterPId))
////                .afterTime(0.2, () -> lifterPId.updateLifterState(LifterPId.LifterState.HOME))
////
////                //Third sample Pick
////                .afterTime(0.8, () -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_PICK))
////                .strafeToLinearHeading(new Vector2d(-53, -43), Math.toRadians(90))
////                .waitSeconds(0.3)
////                .stopAndAdd(() -> new AutoSamplePick(arm, lifterPId))
////
////                //Third Sample Drop
////                .strafeToLinearHeading(new Vector2d(-58, -53), Math.toRadians(45))
////                .stopAndAdd(() -> new AutoSampleDrop(arm, lifterPId))
////                .setTangent(Math.toRadians(40))
////                .splineToLinearHeading(new Pose2d(-18, -10, 0), Math.toRadians(0))
//
//                .build();
//
//
//        Thread pidthread = new Thread(() -> {
//            while (!isStopRequested()) {
//                lifterPId.LIfterPid();
//            }
//        });
//
//
//        if (opModeInInit())
//        {
//            telemetry.addLine("Init");
//            Actions.runBlocking(new SequentialAction(
//                    new InstantAction(()-> new InitSeq(arm, lifterPId)),
//
//            new InstantAction(()-> robot.Claw.setPosition(Globals.ClawOpen)),
//                    new SleepAction(2),
//                    new InstantAction(()-> robot.Claw.setPosition(Globals.ClawClose))
//            ));
//        }
//
//
//        waitForStart();
//
//        pidthread.interrupt();
//
//
//        Actions.runBlocking(new SequentialAction(
//                trajectoryAction0
//        ));
//    }
//}
