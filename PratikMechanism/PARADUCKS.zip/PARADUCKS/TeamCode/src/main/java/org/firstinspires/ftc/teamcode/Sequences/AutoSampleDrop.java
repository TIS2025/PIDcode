package org.firstinspires.ftc.teamcode.Sequences;

import static org.firstinspires.ftc.teamcode.Subsystems.Arm.robot;

import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.ftc.Actions;

import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;

public class AutoSampleDrop {
//    public AutoSampleDrop(Arm arm, LifterPId lifterPID){

    public AutoSampleDrop(Arm arm, Lifter lifter){

        Actions.runBlocking(
                new SequentialAction(
                        new InstantAction(() -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_DROP)),
                        new InstantAction(() -> arm.updateSliderState(Arm.SliderState.SLIDER_SAMPLE_DROP)),
                        new InstantAction(() -> lifter.updateLifterStatee(Lifter.LifterStatee.SAMPLE_DROP)),
                        new SleepAction(1),
                        new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.BASKET_DROP)),
                        new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.BASKET_DROP)),
                        new InstantAction(() -> arm.updateWristState(Arm.WristState.SAMPLE_DROP)),
                        new SleepAction(1),
                        new InstantAction(() -> robot.Claw.setPosition(0.5817)),
                        new SleepAction(1.5),
                        new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.INIT)),
//                        new InstantAction(() -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_PICK)),
                        new InstantAction(() -> arm.updateSliderState(Arm.SliderState.INIT)),
                        new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.INTAKE)),
                        new InstantAction(() -> arm.updateWristState(Arm.WristState.SAMPLE_PICK)),
                        new InstantAction(() -> lifter.updateLifterStatee(Lifter.LifterStatee.HOME))

                )
        );
    }

}
