package org.firstinspires.ftc.teamcode.Sequences;

import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.linearOpMode;
import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.telemetry;
import static org.firstinspires.ftc.teamcode.Hardware.RobotHardware.hardwareMap;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.Globals.Globals;
import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;
import org.firstinspires.ftc.teamcode.MecanumDrive;
import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;


@Config
@Autonomous(name = "Auto_Basket_Side", group = "Autonomous")
public class AutoBasketSeq extends LinearOpMode{

    private final RobotHardware robot = RobotHardware.getInstance();
    private MecanumDrive drive;
    private Arm arm;
    private LifterPId lifterPID;
//    Action trajectoryAction0 = null;

    @Override
    public void runOpMode() throws InterruptedException {

        robot.init(hardwareMap, telemetry);
        arm = new Arm(robot);
        lifterPID = new LifterPId(robot);

        Pose2d initialPose = new Pose2d(-44, -60, Math.toRadians(90));
        drive = new MecanumDrive(hardwareMap, initialPose);

        //TODO ==================================================== Writing Trajectories ======================================================
        Action trajectoryAction0 = drive.actionBuilder(initialPose)

                //TODO ==================================================== Basket Side Auto ======================================================

                //PreLoad Drop
                .strafeToLinearHeading(new Vector2d(-58, -53), Math.toRadians(45))

                .build();

        if (opModeInInit()) {
            telemetry.addLine("Init");
            telemetry.update();
            Actions.runBlocking(new SequentialAction(
                    new InstantAction(() -> new InitSeq(arm, lifterPID)),
                    new InstantAction(() -> robot.Claw.setPosition(Globals.ClawOpen)),
                    new SleepAction(3),
                    new InstantAction(() -> robot.Claw.setPosition(Globals.ClawClose))
            ));
        }


        waitForStart();


        if(opModeIsActive()){
            Actions.runBlocking(new SequentialAction(
                    trajectoryAction0
            ));
        }


    }
}



//                .stopAndAdd(() -> new AutoSampleDrop(arm, lifterPID))
//                .afterTime(0.1, () -> arm.updateClawState(Arm.ClawState.SAMPLE_DROP))
//                .afterTime(0.3, () -> lifterPID.updateLifterState(LifterPId.LifterState.HOME))
//                .afterTime(0.8, () -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_DROP))

//
//                //First Sample Pick
//                .strafeToLinearHeading(new Vector2d(-49.5, -43), Math.toRadians(90))
//                .waitSeconds(0.3)
//                .stopAndAdd(() -> new AutoSamplePick(arm, lifterPID))
//
//
//                .strafeToLinearHeading(new Vector2d(-56, -53), Math.toRadians(45))
//                .stopAndAdd(() -> new AutoSampleDrop(arm, lifterPID))
//                .afterTime(0.2, () -> lifterPID.updateLifterState(LifterPId.LifterState.HOME))
//                .afterTime(0.8, () -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_DROP))
//
//
//                //Second Sample Pick
//                .strafeToLinearHeading(new Vector2d(-62, -42), Math.toRadians(90))
//                .afterTime(0.8, () -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_PICK))
//                .waitSeconds(0.3)
//                .stopAndAdd(() -> new AutoSamplePick(arm, lifterPID))
//
//
//                .strafeToLinearHeading(new Vector2d(-56, -53), Math.toRadians(45))
//                .stopAndAdd(() -> new AutoSampleDrop(arm, lifterPID))
//
//                //Third Sample Pick
//                .stopAndAdd(() -> new AutoSamplePick(arm, lifterPID ))
//                .strafeToLinearHeading(new Vector2d(-59.5, -38), Math.toRadians(135))
//                .afterTime(0.8, () -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_PICK))
//                .waitSeconds(0.3)
//                .stopAndAdd(() -> new AutoSamplePick(arm, lifterPID))
//
//                .strafeToLinearHeading(new Vector2d(-56, -53), Math.toRadians(45))
//                .stopAndAdd(() -> new AutoSampleDrop(arm, lifterPID))
//                //   .stopAndAdd(()-> new AutoSampleDrop(arm, lifterPID))
//                .setTangent(Math.toRadians(40))
//                .splineToLinearHeading(new Pose2d(-18, -10, 0), Math.toRadians(0))
//
//
