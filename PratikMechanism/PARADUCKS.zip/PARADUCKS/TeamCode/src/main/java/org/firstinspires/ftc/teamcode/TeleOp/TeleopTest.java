//package org.firstinspires.ftc.teamcode.TeleOp;
//
//import androidx.annotation.NonNull;
//
//import com.acmerobotics.dashboard.config.Config;
//import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
//import com.acmerobotics.roadrunner.Action;
//import com.acmerobotics.roadrunner.InstantAction;
//import com.acmerobotics.roadrunner.ParallelAction;
//import com.acmerobotics.roadrunner.Pose2d;
//import com.acmerobotics.roadrunner.PoseVelocity2d;
//import com.acmerobotics.roadrunner.SequentialAction;
//import com.acmerobotics.roadrunner.SleepAction;
//import com.acmerobotics.roadrunner.Vector2d;
//import com.acmerobotics.roadrunner.ftc.Actions;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.util.Range;
//
//import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
//import org.firstinspires.ftc.teamcode.Globals.Globals;
//import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;
//import org.firstinspires.ftc.teamcode.MecanumDrive;
//import org.firstinspires.ftc.teamcode.Sequences.BasketSeq;
//import org.firstinspires.ftc.teamcode.Sequences.InitSeq;
//import org.firstinspires.ftc.teamcode.Sequences.IntakeSeq;
//import org.firstinspires.ftc.teamcode.Sequences.SpecimenSeq;
//import org.firstinspires.ftc.teamcode.Subsystems.Arm;
//import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
//import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@TeleOp
//@Config
//public class TeleopTest extends LinearOpMode {
//    public static List<Action> ftc = new ArrayList<>();
//    public static RobotHardware robot=RobotHardware.getInstance();
//
//    public double multiplier=1;
//    public double strafe = 0.7, speed = 0.7, turn = 0.7;
//    public double rackExtend=0.5;
//
//    public static Lifter lifter;
//    public static Arm arm;
//
//    public LifterPId LifterPID;
//    //  private boolean isWrist0 = false;
//    // public static boolean isWrist0 = true;
//
//
//
//    @Override
//    public void runOpMode() throws InterruptedException {
//        MecanumDrive drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
//        robot.init(hardwareMap,telemetry);
//        LifterPID = new LifterPId(robot);
//        arm = new Arm(robot);
//
//        telemetry.addData("Status", "Initialized");
//        telemetry.update();
//
//
//        while (opModeInInit()){
//            Actions.runBlocking(
//                    new SequentialAction(
//                            new InstantAction(()->arm.updateElbowState(Arm.ElbowState.INIT)),
//                            new InstantAction(()->arm.updateClawState(Arm.ClawState.INIT)),
//                            new InstantAction(()->arm.updateWristState(Arm.WristState.INIT)),
//                            new InstantAction(()->arm.updateShoulderState(Arm.ShoulderState.INIT)),
//                            new InstantAction(()->arm.updateSliderState(Arm.SliderState.INIT)),
//                            new InstantAction(()->arm.updateSliderExtendState(Arm.SliderExtendState.INIT)),
//                            new InstantAction(()->LifterPID.updateLifterState(LifterPId.LifterState.HOME))
//                    )
//            );
//        }
//        waitForStart();
//
//
//        while (opModeIsActive()){
//
//            ftc = updateAction();
//            LifterPID.LIfterPid();
//
//
//// TODO =============================================================== SPECIMEN ===========================================================
//
//            if(gamepad1.right_bumper){ // PICK
//                Actions.runBlocking(
//                        new SequentialAction(
//                                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.SPECIMEN_PICK)),
//                                new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.SPECIMEN_PICK)),
//                                new InstantAction(() -> arm.updateWristState(Arm.WristState.SPECIMEN_PICK)),
//                                new InstantAction(() -> arm.updateClawState(Arm.ClawState.OPEN)),
//                                new SleepAction(0.1),
//                                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.HOME))
//
//                        )
//                );
//            }
//
//            if(gamepad1.left_bumper){//PRE Specimen DROP
//                Actions.runBlocking(
//                        new SequentialAction(
//                                new InstantAction(()-> arm.updateClawState(Arm.ClawState.CLOSE)),
//                                new SleepAction(0.1),
//                                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.SPECIMEN_DROP)),
//                                new SleepAction(0.5),
//                                new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.SPECIMEN_DROP)),
//                                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.SPECIMEN_DROP)),
//                                new InstantAction(() -> arm.updateWristState(Arm.WristState.SPECIMEN_DROP)),
//                                new InstantAction(()->arm.updateSliderState(Arm.SliderState.SLIDER_SPECIMEN_DROP))
//                        )
//                );
//            }
//
//            if(gamepad1.y){
//                Actions.runBlocking( //DROP
//                        new SequentialAction(
//                                new InstantAction(()-> robot.Shoulder.setPosition(0.45)),
//                                new SleepAction(0.1),
//                                new InstantAction(()->LifterPID.updateLifterState(LifterPId.LifterState.HOME)),
//                                new SleepAction(0.2),
//                                new InstantAction(()-> robot.Claw.setPosition(0.5817))
////                                new SleepAction(0.2),
////                                new InstantAction(()->arm.updateElbowState(Arm.ElbowState.HOME)),
////                                new InstantAction(()->arm.updateClawState(Arm.ClawState.INIT)),
////                                new InstantAction(()->arm.updateWristState(Arm.WristState.INIT)),
////                                new InstantAction(()->arm.updateShoulderState(Arm.ShoulderState.HOME)),
////                                new InstantAction(()->arm.updateSliderState(Arm.SliderState.HOME)),
////                                new InstantAction(()->arm.updateSliderExtendState(Arm.SliderExtendState.HOME))
//
//                        )
//                );
//            }
//
//            if (gamepad1.dpad_left){
//                ftc.add( //POST SPECIMEN DROP
//                        new SequentialAction(
//                                new InstantAction(()-> robot.Shoulder.setPosition(0.45)),
//                                new SleepAction(0.05),
//                                 new InstantAction(()-> LifterPId.targetPosition = Globals.LifterHome),
//                                new SleepAction(0.18),
//                                new InstantAction(()-> robot.Claw.setPosition(0.5817)),
//                                new InstantAction(()->arm.updateElbowState(Arm.ElbowState.HOME)),
//                                new InstantAction(()->arm.updateClawState(Arm.ClawState.INIT)),
//                                new InstantAction(()->arm.updateWristState(Arm.WristState.INIT)),
//                                new InstantAction(()->arm.updateShoulderState(Arm.ShoulderState.HOME)),
//                                new InstantAction(()->arm.updateSliderState(Arm.SliderState.HOME)),
//                                new InstantAction(()->arm.updateSliderExtendState(Arm.SliderExtendState.HOME))
//                        )
//                );
//            }
//
//
//            //// TRYING NEW METHODS
//
//            if(gamepad1.x){
//                Actions.runBlocking(
//                        new SequentialAction(
//                                new InstantAction(()-> robot.Shoulder.setPosition(0.45)),
//                                new SleepAction(0.1),
//                                new ParallelAction(
//                                        new InstantAction(()->LifterPID.updateLifterState(LifterPId.LifterState.HOME))
//                                ),
//                                new SleepAction(0.2),
//                                new InstantAction(()-> robot.Claw.setPosition(0.5817)),
//                                new InstantAction(()->arm.updateElbowState(Arm.ElbowState.HOME)),
//                                new InstantAction(()->arm.updateClawState(Arm.ClawState.INIT)),
//                                new InstantAction(()->arm.updateWristState(Arm.WristState.INIT)),
//                                new InstantAction(()->arm.updateShoulderState(Arm.ShoulderState.HOME)),
//                                new InstantAction(()->arm.updateSliderState(Arm.SliderState.HOME)),
//                                new InstantAction(()->arm.updateSliderExtendState(Arm.SliderExtendState.HOME))
//
//                        )
//                );
//            }
//
//            if(gamepad1.a){
//
//            }
//
//// Todo ================================================ Wrist Rotation ======================================================================
//
//            if(gamepad1.dpad_down){
//                Actions.runBlocking(
//                        new SequentialAction(
//                                new InstantAction(Arm::toggleWrist) // Call toggle function without parameters
//                        )
//                );
//            }
//
//
//            // Todo ========================================= Robot Oriented ======================================================================
//            drive.setDrivePowers(
//                    new PoseVelocity2d(
//                            new Vector2d(gamepad1.left_stick_y, gamepad1.left_stick_x), gamepad1.right_stick_x / 2)
//            );
//
//            if (gamepad1.left_trigger>0.3){
//                drive.setDrivePowers(
//                        new PoseVelocity2d(
//                                new Vector2d(gamepad1.left_stick_y/2, gamepad1.left_stick_x/2), gamepad1.right_stick_x / 3)
//                );
//            }
//            // Todo =========================================TELEMETRY======================================================================
//
//
//            telemetry.addLine("-----------------------------------");
//
//            telemetry.addData(" Lifter Right Current : ", robot.lifterRight.getCurrent(CurrentUnit.AMPS));
//            telemetry.addData(" Lifter Left 1 Current : ", robot.LifterLeft1.getCurrent(CurrentUnit.AMPS));
//            telemetry.addData(" Lifter Left 2 Current : ", robot.LifterLeft2.getCurrent(CurrentUnit.AMPS));
//
//            telemetry.addLine("-----------------------------------");
//
//            telemetry.addData(" Right Back Current : ", drive.rightBack.getCurrent(CurrentUnit.AMPS));
//            telemetry.addData(" Left Back Current : ", drive.leftBack.getCurrent(CurrentUnit.AMPS));
//            telemetry.addData(" Right Front Current : ", drive.rightFront.getCurrent(CurrentUnit.AMPS));
//            telemetry.addData(" Left Front Current : ", drive.leftFront.getCurrent(CurrentUnit.AMPS));
//
//            telemetry.addLine("-----------------------------------");
//
//            telemetry.addData(" Claw POS : ", robot.Claw.getPosition());
//            telemetry.addData(" Shoulder POS : ", robot.Shoulder.getPosition());
//            telemetry.addData(" Elbow POS : ", robot.Elbow.getPosition());
//            telemetry.addData(" Wrist POS : ", robot.Wrist.getPosition());
//
//            telemetry.addData(" Slider POS : ", robot.Slider.getPosition());
//            telemetry.addData(" Slider Extend POS : ", robot.SliderRight.getPosition());
//            telemetry.addData(" Slider Left POS : ", robot.SliderLeft.getPosition());
//
//            telemetry.addData(" Lifter Right POS : ", robot.lifterRight.getCurrentPosition());
//            telemetry.addData(" Lifter Left 1 POS : ", robot.LifterLeft1.getCurrentPosition());
//            telemetry.addData(" Lifter Left 2 POS : ", robot.LifterLeft2.getCurrentPosition());
//
//            telemetry.addLine("------------------------------------");
//            telemetry.addData("x", drive.localizer.getPose().position.x);
//            telemetry.addData("y", drive.localizer.getPose().position.y);
//
//            telemetry.update();
//
//
//        }
//
//
//    }
//
//    @NonNull
//    public static List<Action> updateAction(){
//        TelemetryPacket packet = new TelemetryPacket();
//        List<Action> newActions = new ArrayList<>();
//
//        for (Action action : ftc) {
//            if (action.run(packet)) {
//                newActions.add(action);
//            }
//        }
//        return newActions;
//    }
//}


package org.firstinspires.ftc.teamcode.TeleOp;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.PoseVelocity2d;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
import org.firstinspires.ftc.teamcode.Globals.Globals;
import org.firstinspires.ftc.teamcode.Hardware.HARDWAREMAPP;
import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;
import org.firstinspires.ftc.teamcode.MecanumDrive;
import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;

import java.util.ArrayList;
import java.util.List;

@TeleOp
@Config
public class TeleopTest extends LinearOpMode {
    public static List<Action> ftc = new ArrayList<>();
    public static HARDWAREMAPP robot= HARDWAREMAPP.getInstance();

    @Override
    public void runOpMode() throws InterruptedException {
        MecanumDrive drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
        robot.init(hardwareMap,telemetry);

        telemetry.addData("Status", "Initialized");
        telemetry.update();


        while (opModeInInit()){
            telemetry.addLine(" Robot initialized ");

        }
        waitForStart();

        while (opModeIsActive()){

            ftc = updateAction();
            if (gamepad1.right_bumper) {
                robot.motorr.setPower(0.5); // Forward
            }
            else if (gamepad1.a){
                robot.motorr.setPower(0); // Stop
            }
            else if (gamepad1.left_bumper) {
                robot.motorr.setPower(-0.5); // Backward
            }

            telemetry.addData("Encoder Ticks", robot.motorr.getCurrentPosition());
            telemetry.addData(" Motor :  ", robot.motorr.getCurrent(CurrentUnit.AMPS));
            telemetry.update();

        }
    }

    @NonNull
    public static List<Action> updateAction(){
        TelemetryPacket packet = new TelemetryPacket();
        List<Action> newActions = new ArrayList<>();

        for (Action action : ftc) {
            if (action.run(packet)) {
                newActions.add(action);
            }
        }
        return newActions;
    }
}
