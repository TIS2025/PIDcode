package org.firstinspires.ftc.teamcode.Sequences;

import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.ftc.Actions;

import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
//import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;

public class AutoInitSeq {
    public AutoInitSeq(Arm arm, Lifter lifter){

            Actions.runBlocking(
                    new SequentialAction(
                            new InstantAction(()->arm.updateElbowState(Arm.ElbowState.INIT)),
                            new InstantAction(()->arm.updateClawState(Arm.ClawState.INIT)),
                            new InstantAction(()->arm.updateWristState(Arm.WristState.INIT)),
                            new InstantAction(()->arm.updateShoulderState(Arm.ShoulderState.INIT)),
                            new InstantAction(()->arm.updateSliderState(Arm.SliderState.INIT)),
                            new InstantAction(()->arm.updateSliderExtendState(Arm.SliderExtendState.INIT))
                    )
            );
        }
    }


