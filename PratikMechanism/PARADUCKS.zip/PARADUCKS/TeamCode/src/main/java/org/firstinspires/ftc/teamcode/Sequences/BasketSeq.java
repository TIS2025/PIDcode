package org.firstinspires.ftc.teamcode.Sequences;

import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;

import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;

public class BasketSeq {
    public static Action SampleDrop(Arm arm, LifterPId LifterPID) {
        return new SequentialAction(
                new InstantAction(() -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_DROP)),
                new InstantAction(() -> arm.updateSliderState(Arm.SliderState.SLIDER_SAMPLE_DROP)),
                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.SAMPLE_DROP)),
                new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.BASKET_DROP)),
                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.BASKET_DROP)),
                new InstantAction(() -> arm.updateWristState(Arm.WristState.SAMPLE_DROP)) ,
                new SleepAction(0.2),
                new InstantAction(() -> arm.updateClawState(Arm.ClawState.OPEN)),
                new SleepAction(0.15)

        );
    }
}


