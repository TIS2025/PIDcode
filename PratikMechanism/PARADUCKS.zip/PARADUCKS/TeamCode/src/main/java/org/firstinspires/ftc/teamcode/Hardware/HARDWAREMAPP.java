package org.firstinspires.ftc.teamcode.Hardware;

import androidx.annotation.NonNull;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;

public class HARDWAREMAPP {

    public DcMotorEx motorr;

    //Todo ========================================================= Robot Setup ===================================================================
    private static HARDWAREMAPP instance = null;    // ref variable to use robot hardware
    public boolean enabled;                          //boolean to return instance if robot is enabled.
    public DcMotorEx motor;

    public static HARDWAREMAPP getInstance() {
        if (instance == null) {
            instance = new HARDWAREMAPP();
        }
        instance.enabled = true;
        return instance;
    }

    public static HardwareMap hardwareMap;

    public void init(HardwareMap hardwareMap, Telemetry telemetry) {
        this.hardwareMap = hardwareMap;

        motorr = hardwareMap.get(DcMotorEx.class, "motor");
        motorr.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
        motorr.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

    }

    public void resetencoder() {
        motorr.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

    }

    public static double convertToTicks(double value,double radius){
        return  (2*Math.PI*radius)/8192;
    }





}
