package org.firstinspires.ftc.teamcode.Hardware;

import androidx.annotation.NonNull;

import com.qualcomm.hardware.rev.RevColorSensorV3;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.OpticalDistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;

public class RobotHardware {

    //arm
    public Servo Shoulder,Elbow,Wrist,Claw;
    
    // lifter
    public DcMotorEx LifterLeft1,LifterLeft2;

    //Todo ========================================================= Robot Setup ===================================================================
    private static RobotHardware instance = null;    // ref variable to use robot hardware
    public boolean enabled;                          //boolean to return instance if robot is enabled.
    public DcMotorEx lifterRight;
    public Servo Slider,SliderLeft,SliderRight;
    public RevColorSensorV3 colorSensor;


    public static RobotHardware getInstance() {
        if (instance == null) {
            instance = new RobotHardware();
        }
        instance.enabled = true;
        return instance;
    }

    public static HardwareMap hardwareMap;

    public void init(HardwareMap hardwareMap, Telemetry telemetry) {
         this.hardwareMap = hardwareMap;

         //Arm
         Shoulder = hardwareMap.get(Servo.class, "Shoulder");
         Elbow = hardwareMap.get(Servo.class, "Elbow");
         Wrist = hardwareMap.get(Servo.class, "Wrist");
         Claw = hardwareMap.get(Servo.class,"Claw");

        //Slider
         Slider = hardwareMap.get(Servo.class,"Slider");
         SliderLeft = hardwareMap.get(Servo.class,"Slider_Left");
         SliderRight = hardwareMap.get(Servo.class,"Slider_Right");

         //Lifter
         lifterRight = hardwareMap.get(DcMotorEx.class,"LifterRight");
         lifterRight.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
//         lifterRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
         lifterRight.setDirection(DcMotorSimple.Direction.REVERSE);

         LifterLeft1 = hardwareMap.get(DcMotorEx.class, "LifterLeft1");
         LifterLeft1.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
//         LifterLeft1.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

         LifterLeft2 = hardwareMap.get(DcMotorEx.class, "LifterLeft2");
         LifterLeft2.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
//         LifterLeft2.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);



        //Color Sensor
        colorSensor = hardwareMap.get(RevColorSensorV3.class, "test_color");


    }

public void resetencoder() {
        lifterRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        LifterLeft1.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        LifterLeft2.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

    }
        // TODO ====  Gripper , Arm , Wrist , Shoulder, Rack , Left Rack Extend ,  Right Rack Extend  ( Servo )
        // TODO ==== Left Lifter Motor , Right Lifter Motor , Right2 Lifter Motor , Hanger Motor


    public static double convertToTicks(double value,double radius){
        return  (2*Math.PI*radius)/8192;
    }




        
}
