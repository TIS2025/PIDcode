package org.firstinspires.ftc.teamcode.Subsystems;

import static org.firstinspires.ftc.teamcode.Subsystems.Lifter.LifterStatee.HOME;

import androidx.annotation.NonNull;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.teamcode.Globals.Globals;
import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;

public class Lifter {
    private final RobotHardware robot;

    public Lifter(RobotHardware  robot){
        this.robot = robot;
    }

    public enum LifterStatee{
        INIT,
        HOME,
        INTAKE,
        SPECIMEN_DROP,
        SAMPLE_DROP
    }

    public LifterStatee Lifterstate = LifterStatee.INIT;

    public void updateLifterStatee(@NonNull LifterStatee state){
        switch(state) {
            case HOME:
                setLifter(Globals.LifterHome);
                break;

            case SPECIMEN_DROP:
                setLifter(Globals.LifterSpecimenDrop);
                break;

            case INTAKE:
                setLifter(Globals.LifterSamplePick);
                break;

            case SAMPLE_DROP:
                setLifter(Globals.LifterSampleDrop);
                break;

        }this.Lifterstate = state;
    }

    public void setLifter(int target) {
//        target = Math.max(Math.min(target, 2600), 0);
        robot.LifterLeft1.setTargetPosition(target);
        robot.LifterLeft2.setTargetPosition(target);
        robot.lifterRight.setTargetPosition(target);

        robot.LifterLeft1.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        robot.LifterLeft2.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        robot.lifterRight.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);

        robot.LifterLeft1.setPower(1);
        robot.LifterLeft2.setPower(1);
        robot.lifterRight.setPower(1);




    }









    //   public void setLifterRight(double pos)
   //     {robot.LifterRight.setPositionPIDFCoefficients(pos);}

    }