package org.firstinspires.ftc.teamcode.Sequences;

import static org.firstinspires.ftc.teamcode.Subsystems.Arm.robot;

import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;

import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;

public class SpecimenSeq {

    public static Action SpecimenPick(Arm arm,LifterPId LifterPID){
        return new SequentialAction(
                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.SPECIMEN_PICK)),
                new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.SPECIMEN_PICK)),
                new InstantAction(() -> arm.updateWristState(Arm.WristState.SPECIMEN_PICK)),
                new InstantAction(() -> arm.updateClawState(Arm.ClawState.OPEN)),
                new SleepAction(0.1),
                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.HOME))

        );
    }

    public static Action SpecimenPreDrop(Arm arm,LifterPId LifterPID){
        return new SequentialAction(
                new InstantAction(()-> arm.updateClawState(Arm.ClawState.CLOSE)),
                new SleepAction(0.1),
                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.SPECIMEN_DROP)),
                new SleepAction(0.5),
                new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.SPECIMEN_DROP)),
                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.SPECIMEN_DROP)),
                new InstantAction(() -> arm.updateWristState(Arm.WristState.SPECIMEN_DROP)),
                new InstantAction(()->arm.updateSliderState(Arm.SliderState.SLIDER_SPECIMEN_DROP))
                );
    }

    public static Action SpecimenDrop(Arm arm,LifterPId LifterPID) {
        return new SequentialAction(
                new InstantAction(() -> robot.Shoulder.setPosition(0.45)),
                new SleepAction(0.1),
                new InstantAction(() -> LifterPID.updateLifterState(LifterPId.LifterState.HOME)),
                new SleepAction(0.2),
                new InstantAction(() -> robot.Claw.setPosition(0.5817)),
                new SleepAction(0.2),
                new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.HOME)),
                new InstantAction(() -> arm.updateClawState(Arm.ClawState.INIT)),
                new InstantAction(() -> arm.updateWristState(Arm.WristState.INIT)),
                new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.HOME)),
                new InstantAction(() -> arm.updateSliderState(Arm.SliderState.HOME)),
                new InstantAction(() -> arm.updateSliderExtendState(Arm.SliderExtendState.HOME))
        );
    }
}
