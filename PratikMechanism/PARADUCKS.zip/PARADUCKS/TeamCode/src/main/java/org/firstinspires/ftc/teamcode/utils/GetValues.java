package org.firstinspires.ftc.teamcode.utils;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.PoseVelocity2d;
import com.acmerobotics.roadrunner.Vector2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.util.Range;
import com.qualcomm.robotcore.util.Util;

import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
import org.firstinspires.ftc.teamcode.Globals.Globals;
import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;
import org.firstinspires.ftc.teamcode.MecanumDrive;

@TeleOp(name="GetValuesTanishka", group="TeleOp")
public class GetValues extends LinearOpMode {
    public double botHeading;
    public static RobotHardware robot=RobotHardware.getInstance();

    public double multiplier=1;
    public double strafe = 0.7, speed = 0.7, turn = 0.7;
    public double rackExtend=0.5;

    @Override
    public void runOpMode() {


        MecanumDrive drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
        robot.init(hardwareMap,telemetry);

        telemetry.addData("Status", "Initialized");
        telemetry.update();

        while (opModeInInit()) {
            robot.Shoulder.setPosition(0.5);
            robot.Claw.setPosition(0.5);
            robot.Elbow.setPosition(0.5);
            robot.Wrist.setPosition(0.5);
            robot.Slider.setPosition(0.5);
            robot.SliderLeft.setPosition(rackExtend);
            robot.SliderRight.setPosition(rackExtend);
        }

        waitForStart();

        while (opModeIsActive()) {


            // TODO =============================================== INIT===========================================================

            if(gamepad1.a) {
                robot.Shoulder.setPosition(robot.Shoulder.getPosition() - 0.001);
            }
            if(gamepad1.b){
                robot.Shoulder.setPosition(robot.Shoulder.getPosition() + 0.001);
            }


            if(gamepad1.x) {
                robot.Elbow.setPosition(robot.Elbow.getPosition() - 0.001);
            }
            if(gamepad1.y){
                robot.Elbow.setPosition(robot.Elbow.getPosition() + 0.001);
            }


            if(gamepad1.dpad_up) {
                robot.Wrist.setPosition(robot.Wrist.getPosition() - 0.001);
            }
            if(gamepad1.dpad_down){
                robot.Wrist.setPosition(robot.Wrist.getPosition() + 0.001);
            }


            if(gamepad1.dpad_right) {
                robot.Claw.setPosition(robot.Claw.getPosition() - 0.001);
            }
            if(gamepad1.dpad_left){
                robot.Claw.setPosition(robot.Claw.getPosition() + 0.001);
            }


            if(gamepad1.right_bumper) {
                rackExtend -= 0.001;
                ExtendSlider(rackExtend);
            }
            if(gamepad1.left_bumper){
                rackExtend += 0.001;
                ExtendSlider(rackExtend);
            }

            if(gamepad1.start){
                robot.Slider.setPosition(robot.Slider.getPosition() + 0.001);
            }
            if(gamepad1.back){
                robot.Slider.setPosition(robot.Slider.getPosition() - 0.001);
            }

            if(gamepad1.right_trigger > 0.2){
                lifterDown();
            }
            if(gamepad1.left_trigger > 0.2){
                lifterUp();

            }

            drive.updatePoseEstimate();

            // Todo ========================================= Robot Oriented ======================================================================
            drive.setDrivePowers(
                    new PoseVelocity2d(
                            new Vector2d(Math.pow(Range.clip(-gamepad1.left_stick_y*speed,-1,1),3),
                                    Math.pow(Range.clip(-gamepad1.left_stick_x*strafe,-1,1),3)),
                            Math.pow(Range.clip(-gamepad1.right_stick_x*turn,-1,1),3))
            );

            if (gamepad1.left_stick_x>0.3){
                drive.setDrivePowers(
                        new PoseVelocity2d(
                                new Vector2d(Math.pow(Range.clip(gamepad1.left_stick_y*speed*multiplier,-1,1),3),
                                        Math.pow(Range.clip(gamepad1.left_stick_x*strafe*multiplier,-1,1),3)),
                                Math.pow(Range.clip(-gamepad1.right_stick_x*turn*multiplier,-1,1),3))
                );
            }
            // Todo =========================================TELEMETRY======================================================================


            telemetry.addLine("-----------------------------------");

            telemetry.addData(" Lifter Right Current : ", robot.lifterRight.getCurrent(CurrentUnit.AMPS));
            telemetry.addData(" Lifter Left 1 Current : ", robot.LifterLeft1.getCurrent(CurrentUnit.AMPS));
            telemetry.addData(" Lifter Left 2 Current : ", robot.LifterLeft2.getCurrent(CurrentUnit.AMPS));

            telemetry.addLine("-----------------------------------");

            telemetry.addData(" Right Back Current : ", drive.rightBack.getCurrent(CurrentUnit.AMPS));
            telemetry.addData(" Left Back Current : ", drive.leftBack.getCurrent(CurrentUnit.AMPS));
            telemetry.addData(" Right Front Current : ", drive.rightFront.getCurrent(CurrentUnit.AMPS));
            telemetry.addData(" Left Front Current : ", drive.leftFront.getCurrent(CurrentUnit.AMPS));

            telemetry.addLine("-----------------------------------");

            telemetry.addData(" Claw POS : ", robot.Claw.getPosition());
            telemetry.addData(" Shoulder POS : ", robot.Shoulder.getPosition());
            telemetry.addData(" Elbow POS : ", robot.Elbow.getPosition());
            telemetry.addData(" Wrist POS : ", robot.Wrist.getPosition());

            telemetry.addData(" Slider POS : ", robot.Slider.getPosition());
            telemetry.addData(" Slider Extend POS : ", robot.SliderRight.getPosition());
            telemetry.addData(" Slider Left POS : ", robot.SliderLeft.getPosition());

            telemetry.addData(" Lifter Right POS : ", robot.lifterRight.getCurrentPosition());
            telemetry.addData(" Lifter Left 1 POS : ", robot.LifterLeft1.getCurrentPosition());
            telemetry.addData(" Lifter Left 2 POS : ", robot.LifterLeft2.getCurrentPosition());

            telemetry.addLine("------------------------------------");
            telemetry.addData("x", drive.localizer.getPose().position.x);
            telemetry.addData("y", drive.localizer.getPose().position.y);

            telemetry.update();

        }

    }

    public static void ExtendSlider(double val){
        robot.SliderRight.setPosition(val);
        robot.SliderLeft.setPosition(1-val);
    }


    public static void lifterUp(){
        robot.LifterLeft1.setTargetPosition(robot.LifterLeft1.getCurrentPosition() + 50);
        robot.LifterLeft2.setTargetPosition(robot.LifterLeft2.getCurrentPosition() + 50);
        robot.lifterRight.setTargetPosition(robot.lifterRight.getCurrentPosition() + 50);

        robot.LifterLeft1.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        robot.LifterLeft2.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        robot.lifterRight.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);

        robot.LifterLeft1.setPower(0.5);
        robot.LifterLeft2.setPower(0.5);
        robot.lifterRight.setPower(0.5);
    }

    public static void lifterDown(){
        robot.LifterLeft1.setTargetPosition(robot.LifterLeft1.getCurrentPosition() - 50);
        robot.LifterLeft2.setTargetPosition(robot.LifterLeft2.getCurrentPosition() - 50);
        robot.lifterRight.setTargetPosition(robot.lifterRight.getCurrentPosition() - 50);

        robot.LifterLeft1.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        robot.LifterLeft2.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        robot.lifterRight.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);

        robot.LifterLeft1.setPower(0.5);
        robot.LifterLeft2.setPower(0.5);
        robot.lifterRight.setPower(0.5);
    }
}