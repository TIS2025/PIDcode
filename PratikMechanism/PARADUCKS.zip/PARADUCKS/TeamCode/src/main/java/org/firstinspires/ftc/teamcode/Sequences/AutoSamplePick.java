package org.firstinspires.ftc.teamcode.Sequences;

import static org.firstinspires.ftc.teamcode.Subsystems.Arm.robot;

import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.ftc.Actions;

import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;

public class AutoSamplePick {
    public AutoSamplePick(Arm arm, Lifter lifter){

        Actions.runBlocking( //PICK(INTAKE)
                new SequentialAction(
                    //    new InstantAction(() -> lifter.updateLifterStatee(Lifter.LifterStatee.HOME)),
//                        new InstantAction(() -> arm.updateSliderExtendState(Arm.SliderExtendState.SLIDEREXTEND_SAMPLE_PICK)),
                        new InstantAction(() -> arm.updateSliderState(Arm.SliderState.SLIDER_SAMPLE_PICK)),
                        //     new InstantAction(() -> robot.Shoulder.setPosition(0.639)),
                        new InstantAction(() -> arm.updateElbowState(Arm.ElbowState.INTAKE)),
                        new InstantAction(() -> robot.Shoulder.setPosition(0.60)),
                        new SleepAction(0.15),
                        new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.INTAKE)),
                        new InstantAction(() -> arm.updateWristState(Arm.WristState.SAMPLE_PICK)),
                        new InstantAction(() -> arm.updateClawState(Arm.ClawState.OPEN)),
                        new SleepAction(3),
                        new InstantAction(() -> arm.updateClawState(Arm.ClawState.CLOSE)),
                        new SleepAction(0.15),
                        new InstantAction(() -> arm.updateShoulderState(Arm.ShoulderState.INIT))

                )
        );

    }

    }
