//package org.firstinspires.ftc.teamcode.TeleOp;
//
//import androidx.annotation.NonNull;
//
//import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
//import com.acmerobotics.roadrunner.Action;
//import com.acmerobotics.roadrunner.Pose2d;
//import com.acmerobotics.roadrunner.PoseVelocity2d;
//import com.acmerobotics.roadrunner.Vector2d;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
//import com.qualcomm.robotcore.hardware.Gamepad;
//import com.qualcomm.robotcore.util.Range;
//
//import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
//import org.firstinspires.ftc.teamcode.Globals.Globals;
//import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;
//import org.firstinspires.ftc.teamcode.MecanumDrive;
//import org.firstinspires.ftc.teamcode.Sequences.IntakeSeq;
//import org.firstinspires.ftc.teamcode.Sequences.InitSeq;
//import org.firstinspires.ftc.teamcode.Sequences.BasketSeq;
//import org.firstinspires.ftc.teamcode.Sequences.SpecimenSeq;
//import org.firstinspires.ftc.teamcode.Subsystems.Arm;
//import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
//import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@TeleOp(group = "ParaTeleOp", name = "TeleOp Paraducks")
//public class BasicTeleOp extends LinearOpMode {
//    static List<Action> ftc = new ArrayList<>();
//    MecanumDrive drive;
//    public static double turn_coeff = 0.5;
//    double botHeading;
//
//    enum BotState{
//        SAMPLE_MODE,
//        SPECIMEN_MODE
//    }
//
//    enum SampleState{
//        HOME_POS,
//        PICK_POS,
//        PICK,
//        DROP_POS,
//    }
//
//    enum SpecimenState{
//        PICK_POS,
//        DROP_POS,
//    }
//
//    enum DriveState{
//        FIELD_CENTRIC,
//        BOT_CENTRIC
//    }
//
//    SampleState sampleState = SampleState.HOME_POS;
//    SpecimenState specimenState = SpecimenState.PICK_POS;
//    BotState intakeState = BotState.SAMPLE_MODE;
//    DriveState driveState = DriveState.BOT_CENTRIC;
//
//    //FLAGS
// //   boolean HANGER_FLAG2 = false;
// //   boolean HANGER_FLAG1 = false;
//
//    @Override
//    public void runOpMode() throws InterruptedException {
//        RobotHardware robot = new RobotHardware();
//
//        drive = new MecanumDrive(hardwareMap,new Pose2d(new Vector2d(0,0),0));
//        Lifter lifter = new Lifter(robot);
//        Arm arm = new Arm(robot);
//
//        Gamepad C1 = new Gamepad();
//        Gamepad P1 = new Gamepad();
//
//        Gamepad C2 = new Gamepad();
//        Gamepad P2 = new Gamepad();
//
//        int slider_pos = 0;
//
//        boolean wrist_rotate = true;
//        double distance;
//        double drive_coeff = 1;
//
//        while (opModeInInit()){
//            P1.copy(C1);
//            C1.copy(gamepad1);
//            P2.copy(C2);
//            C2.copy(gamepad2);
//
//            new InitSeq(arm, LifterPId lifterPID);
//
//            if(C2.left_stick_button && !P2.left_stick_button && driveState==DriveState.BOT_CENTRIC){
//                driveState = DriveState.FIELD_CENTRIC;
//            }
//            if(C2.left_stick_button && !P2.left_stick_button && driveState==DriveState.FIELD_CENTRIC){
//                driveState = DriveState.BOT_CENTRIC;
//            }
//
//            telemetry.update();
//        }
//
////        robot.reset_encoders();
//        waitForStart();
//
//        while(opModeIsActive()){
//            P1.copy(C1);
//            C1.copy(gamepad1);
//            P2.copy(C2);
//            C2.copy(gamepad2);
//
//            drive.setDrivePowers(
//                    driveCommand(C1,drive_coeff)
//            );
//
//           }
//
//            ftc = updateAction();
//
//            if(C1.left_trigger>0.5) drive_coeff = 0.25;
//            else drive_coeff = 1;
//
////
////            if(C2.dpad_left && !P2.dpad_left && specimenState == SpecimenState.PICK_POS){
////                intakeState = BotState.SAMPLE_MODE;
////                ftc.add(IntakeSeq.Home(arm,lifter));
////
//            //}
//          //  if(C1.a && !P1.a && intakeState == BotState.SAMPLE_MODE && (sampleState == SampleState.HOME_POS || sampleState == SampleState.PICK_POS || sampleState == SampleState.PICK)){
//          //      ftc.add(IntakeSeq.Home(arm,lifter));
//          //      sampleState = SampleState.HOME_POS;
//
//            //}
//
//
//          //  if(C1.x && !P1.x && intakeState == BotState.SAMPLE_MODE && sampleState == SampleState.PICK_POS){
//          //      ftc.add(IntakeSeq.SampleIntake(arm,lifter));
//          //      sampleState = SampleState.PICK;
//          //      wrist_rotate = true;
//          //      slider_pos = 0;
//          //  }
///*
//            if(C1.left_bumper && !P1.left_bumper && intakeState == BotState.SAMPLE_MODE && sampleState == SampleState.PICK){
//                ftc.add(BasketSeq.PreDrop(arm,lifter));
//                sampleState = SampleState.DROP_POS;
//            }
//
//            if(C1.right_bumper && !P1.right_bumper && intakeState == BotState.SAMPLE_MODE && sampleState == SampleState.DROP_POS){
//                ftc.add(BasketSeq.SampleDrop(arm,lifter));
//                sampleState = SampleState.HOME_POS;
//            }
//*/
//
//            if(C1.right_bumper /*&& !P1.right_bumper && intakeState == BotState.SPECIMEN_MODE && specimenState == SpecimenState.DROP_POS*/){
//                ftc.add(SpecimenSeq.SpecimenPick(arm,lifter));
//                specimenState = SpecimenState.PICK_POS;
//            }
//            if(C1.left_bumper /*&& !P1.left_bumper && intakeState == BotState.SPECIMEN_MODE && specimenState == SpecimenState.PICK_POS*/) {
//                ftc.add(SpecimenSeq.SpecimenDrop(arm,lifter));
//                specimenState = SpecimenState.DROP_POS;
//            }
//
//            telemetry.addData("Slider Pos",robot.Slider.getPosition());
//            telemetry.addData("Slider left Pos",robot.SliderLeft.getPosition());
//            telemetry.addData("Extended Slider Pos",robot.SliderRight.getPosition());
//            telemetry.addData("Drive State",driveState);
//            telemetry.addData("Bot State",intakeState);
//            telemetry.addData("Wrist state",wrist_rotate);
//    //        telemetry.addData("Claw State",Arm.ClawState);
//            telemetry.addData("Drive Current FL",drive.leftFront.getCurrent(CurrentUnit.MILLIAMPS));
//            telemetry.addData("Drive Current FR",drive.rightFront.getCurrent(CurrentUnit.MILLIAMPS));
//            telemetry.addData("Drive Current BL",drive.leftBack.getCurrent(CurrentUnit.MILLIAMPS));
//            telemetry.addData("Drive Current BR",drive.rightBack.getCurrent(CurrentUnit.MILLIAMPS));
//            telemetry.update();
//        }
//
//    @NonNull
//    private static List<Action> updateAction() {
//        TelemetryPacket packet = new TelemetryPacket();
//        List<Action> newActions = new ArrayList<>();
//        for (Action action : BasicTeleOp.ftc) {
//            if (action.run(packet)) {
//                newActions.add(action);
//            }
//        }
//        return newActions;
//    }
//
//    private static PoseVelocity2d driveCommand(Gamepad G, double drive_coeff){
//        double x = Math.pow(Range.clip(-G.left_stick_y,-1,1),3)*drive_coeff;
//        double y = Math.pow(Range.clip(-G.left_stick_x,-1,1),3)*drive_coeff;
//        double angVel = Math.pow(Range.clip(-G.right_stick_x,-1,1),3)* BasicTeleOp.turn_coeff;
//
//        return new PoseVelocity2d(new Vector2d(x,y),angVel);
//    }
//
//
//}
//
