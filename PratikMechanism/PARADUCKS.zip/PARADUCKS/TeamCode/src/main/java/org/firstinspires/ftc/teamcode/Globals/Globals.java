package org.firstinspires.ftc.teamcode.Globals;

import com.acmerobotics.dashboard.config.Config;

@Config
public class Globals {

    // TODO==========================================================  Elevator Value ====================================================
    public static int home = 0;
    public static int highRung = 850;
    public static int lowRung = 400;
    public static int highBasket = 1100;


    // TODO==========================================================  Hanging Value ====================================================

    public static int hangPos = 0;
    public static int hangDone = -1100;


    // TODO==========================================================  Gripper Value ====================================================

    public static double ClawInit = 0.5817;
    public static double ClawOpen = ClawInit;
    public static double ClawClose = 0.3400;
    public static double ClawSamplePick = 0.3344;
    public static double ClawSampleDrop = 0.5344;


    // TODO==========================================================  Wrist Value ====================================================

    public static double Wrist0 = 0.2439;
    public static double WristInit = 0.2439;
    public static double Wrist90 = 0;
    public static double WristSamplePick = 0.2606;
    public static double WristSampleDrop = 0.2561;
    public static double WristSpecimenPick = 0.8017;
    public static double WristSpecimenDrop = 0.2428;


    // TODO =============================== Elbow Value =========================================

    public static double ElbowInit = 0.4389;

    public static double ElbowIntake = 0.4387; //0.4394
    public static double ElbowBasketDrop = 0.4339;
    public static double AutoElbowIntake = ElbowInit;
    public static double ElbowSpecimenPick = 0.0528;
    public static double ElbowSpecimenDrop = 0.4722;


    // TODO ============================ Shoulder Value ============================

    public static double ShoulderInit = 0.3533;
    public static double ShoulderHome = ShoulderInit;

    public static double ShoulderIntake = 0.675;
    public static double ShoulderBasketDrop = 0.50;

    public static double ShoulderSpecimenPick = 0.1261;
    public static double ShoulderSpecimenDrop = 0.3511;

    // TODO ============================ Slider Value ==================================================

    public static double SliderInit = 0.3889;
    public static double SliderSampleDrop = 0.1778;
    public static double SliderSpecimenPick = 0.2706;
    public static double SliderSpecimenDrop = 0.2739;
    public static double SliderSamplePrePick = 0.1089;
    public static double SliderSamplePick = 0.1089;


    public static double SliderExtendInit = 0.6267;
    public static double SliderExtendSamplePick = 0.2694;
    public static double SliderExtendSampleDrop = 0.6417;
    public static double SliderExtendSpecimenPick = SliderExtendInit;
    public static double SliderExtendSpecimenDrop = 0.6478;


    // TODO ============================ Lifter Value ==================================================


    public static int LifterHome = 0;
    public static int LifterSpecimenDrop = 835;
    public static int LifterSamplePick = 0;
    public static int LifterSampleDrop = 2700;


}





//
//    public static int LifterLeft1Init = 0;
//    public static int LifterLeft1Home = 0;
//    public static int LifterLeft1Up = 0;
//    public static int LifterLeft1Down = 0;
//    public static int LifterLeft1PreIntake = 0;
//    public static int LifterLeft1Intake = 0;
//    public static int LifterLeft1PostIntake = 0;
//    public static int LifterLeft1SpecimenDrop = 831;
//
//    public static int LifterLeft2Init = 0;
//    public static int LifterLeft2Home = 0;
//    public static int LifterLeft2Up = 0;
//    public static int LifterLeft2Down = 0;
//    public static int LifterLeft2PreIntake = 0;
//    public static int LifterLeft2Intake = 0;
//    public static int LifterLeft2PostIntake = 0;
//    public static int LifterLeft2SpecimenDrop = 825;
//
//    public static int LifterRightInit = 0 ;
//    public static int LifterRightHome = 0;
//    public static int LifterRightUp = 0;
//    public static int LifterRightDown = 0;
//    public static int LifterRightPreIntake = 0;
//    public static int LifterRightIntake = 0;
//    public static int LifterRightPostIntake = 0;
//    public static int LifterRightSpecimenDrop = 848;

//    public static int LifterLeft2Power = 0;
//    public static int LifterRightPower = 0;
//    public static int LifterLeft1Power = 0;
//    public static int LifterInc = 0;






