package org.firstinspires.ftc.teamcode.Subsystems;

import androidx.annotation.NonNull;

import org.firstinspires.ftc.teamcode.Globals.Globals;
import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;

public class Arm {

    public static RobotHardware robot = null;


    public static boolean isWrist0 = true;

    public Arm(RobotHardware robot) {
        this.robot = robot;
    }

    public enum ClawState {
        INIT,
        OPEN,
        CLOSE,
        SAMPLE_DROP,
        SAMPLE_PICK
    }

    public enum WristState {
        INIT,
        WRIST0,
        WRIST90,
        SAMPLE_PICK,
        SAMPLE_DROP,
        SPECIMEN_PICK,
        SPECIMEN_DROP
    }

    public enum ElbowState {
        INIT,
        HOME,
        INTAKE,
        AUTO_SAMPLE_INTAKE,
        BASKET_DROP,
        SPECIMEN_PICK,
        SPECIMEN_DROP
    }

    public enum ShoulderState {
        INIT,
        HOME,
        INTAKE,
        POST_INTAKE,
        BASKET_DROP,
        SPECIMEN_PICK,
        SPECIMEN_DROP
    }

    public enum SliderState {
        INIT,
        HOME,
        SLIDER_SPECIMEN_PICK,
        SLIDER_SPECIMEN_DROP,
        SLIDER_SAMPLE_PRE_PICK,
        SLIDER_SAMPLE_PICK,
        SLIDER_SAMPLE_DROP
    }

    public enum SliderExtendState {
        INIT,
        HOME,
        SLIDEREXTEND_SAMPLE_PICK,
        SLIDEREXTEND_SAMPLE_DROP,
        SLIDEREXTEND_SPECIMEN_PICK,
        SLIDEREXTEND_SPECIMEN_DROP
    }


    public ClawState claw = ClawState.INIT;
    public WristState wrist = WristState.INIT;
    public ElbowState elbow = ElbowState.INIT;
    public ShoulderState shoulder = ShoulderState.INIT;
    public SliderState slider = SliderState.INIT;
    public SliderExtendState ExtendSlider = SliderExtendState.INIT;


    public void updateClawState(@NonNull ClawState state) {
        this.claw = state;
        switch (state) {
            case INIT:
                setClaw(Globals.ClawInit);
                break;

            case OPEN:
                setClaw(Globals.ClawOpen);
                break;

            case CLOSE:
                setClaw(Globals.ClawClose);
                break;

            case SAMPLE_PICK:
                setClaw(Globals.ClawSamplePick);
                break;

            case SAMPLE_DROP:
                setClaw(Globals.ClawSampleDrop);
                break;


        }
    }

    public void updateWristState( WristState state) {
        this.wrist = state;

        switch (state) {
            case WRIST0:
                setWrist(Globals.Wrist0);
                break;

            case INIT:
                setWrist(Globals.WristInit);
                break;

            case WRIST90:
                setWrist(Globals.Wrist90);
                break;

            case SAMPLE_PICK:
                setWrist(Globals.WristSamplePick);
                break;

            case SAMPLE_DROP:
                setWrist(Globals.WristSampleDrop);
                break;

            case SPECIMEN_PICK:
                setWrist(Globals.WristSpecimenPick);
                break;

            case SPECIMEN_DROP:
                setWrist(Globals.WristSpecimenDrop);
                break;
        }
    }

    public void updateElbowState(@NonNull ElbowState state) {
        this.elbow = state;

        switch (state) {

            case INIT:
                setElbow(Globals.ElbowInit);
                break;

            case INTAKE:
                setElbow(Globals.ElbowIntake);
                break;

            case BASKET_DROP:
                setElbow(Globals.ElbowBasketDrop);
                break;


            case AUTO_SAMPLE_INTAKE:
                setElbow(Globals.AutoElbowIntake);
                break;


            case SPECIMEN_PICK:
                setElbow(Globals.ElbowSpecimenPick);
                break;

            case SPECIMEN_DROP:
                setElbow(Globals.ElbowSpecimenDrop);
                break;


        }
    }

    public void updateShoulderState(@NonNull ShoulderState state) {
        this.shoulder = state;

        switch (state) {
            case INIT:
                setShoulder(Globals.ShoulderInit);
                break;

            case HOME:
                setShoulder(Globals.ShoulderHome);
                break;

            case INTAKE:
                setShoulder(Globals.ShoulderIntake);
                break;

            case BASKET_DROP:
                setShoulder(Globals.ShoulderBasketDrop);
                break;

            case SPECIMEN_PICK:
                setShoulder(Globals.ShoulderSpecimenPick);
                break;

            case SPECIMEN_DROP:
                setShoulder(Globals.ShoulderSpecimenDrop);
                break;

        }
    }


    public void updateSliderState(@NonNull SliderState state) {
        this.slider = state;
        switch (state) {
            case INIT:
                setSlider(Globals.SliderInit);
                break;

            case SLIDER_SPECIMEN_PICK:
                setSlider(Globals.SliderSpecimenPick);
                break;

            case SLIDER_SPECIMEN_DROP:
                setSlider(Globals.SliderSpecimenDrop);
                break;

            case SLIDER_SAMPLE_PRE_PICK:
                setSlider(Globals.SliderSamplePrePick);
                break;

            case SLIDER_SAMPLE_PICK:
                setSlider(Globals.SliderSamplePick);
                break;

            case SLIDER_SAMPLE_DROP:
                setSlider(Globals.SliderSampleDrop);
                break;


        }
    }

    public void updateSliderExtendState(@NonNull SliderExtendState state) {
        this.ExtendSlider = state;
        switch (state) {
            case INIT:
                ExtendSlider(Globals.SliderExtendInit);
                break;

            case SLIDEREXTEND_SAMPLE_PICK:
                ExtendSlider(Globals.SliderExtendSamplePick);
                break;

            case SLIDEREXTEND_SAMPLE_DROP:
                ExtendSlider(Globals.SliderExtendSampleDrop);
                break;

            case SLIDEREXTEND_SPECIMEN_PICK:
                ExtendSlider(Globals.SliderExtendSpecimenPick);
                break;

            case SLIDEREXTEND_SPECIMEN_DROP:
                ExtendSlider(Globals.SliderExtendSpecimenDrop);
                break;


        }
    }


    public static void setClaw(double pos) {
        robot.Claw.setPosition(pos);
    }

    public static void setWrist(double pos) {
        robot.Wrist.setPosition(pos);
    }

    public static void setElbow(double pos) {
        robot.Elbow.setPosition(pos);
    }

    public static void setShoulder(double pos) {
        robot.Shoulder.setPosition(pos);
    }

    public static void setSlider(double pos) {
        robot.Slider.setPosition(pos);
    }

    public void ExtendSlider(double val) {
        robot.SliderRight.setPosition(val);
        robot.SliderLeft.setPosition(1 - val);
    }

}

