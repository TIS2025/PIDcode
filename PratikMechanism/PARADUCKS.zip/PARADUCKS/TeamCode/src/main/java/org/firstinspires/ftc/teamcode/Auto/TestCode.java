
package org.firstinspires.ftc.teamcode.Auto;

import static org.firstinspires.ftc.teamcode.Hardware.RobotHardware.hardwareMap;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantAction;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.Globals.Globals;
import org.firstinspires.ftc.teamcode.Hardware.RobotHardware;
import org.firstinspires.ftc.teamcode.MecanumDrive;
import org.firstinspires.ftc.teamcode.Sequences.AutoInitSeq;
import org.firstinspires.ftc.teamcode.Sequences.AutoSampleDrop;
import org.firstinspires.ftc.teamcode.Sequences.AutoSamplePick;
import org.firstinspires.ftc.teamcode.Sequences.InitSeq;
import org.firstinspires.ftc.teamcode.Subsystems.Arm;
import org.firstinspires.ftc.teamcode.Subsystems.Lifter;
import org.firstinspires.ftc.teamcode.Subsystems.LifterPId;

@Config
@Autonomous(name = "TestCode", group = "Autonomous")
public class TestCode extends LinearOpMode {
    public final RobotHardware robot = RobotHardware.getInstance();
    public MecanumDrive drive;
    private Arm arm;
   // private LifterPId lifterPId;
    private Lifter lifter;

    @Override
    public void runOpMode() throws InterruptedException {
        Pose2d initialPose = new Pose2d(-40, -60, Math.toRadians(90));

            robot.init(hardwareMap, telemetry);
            arm = new Arm(robot);
            lifter = new Lifter(robot);


            drive = new MecanumDrive(hardwareMap, initialPose);

            Action trajectoryAction0 = drive.actionBuilder(initialPose)

                //preload drop
                .strafeToLinearHeading(new Vector2d(-60, -53), Math.toRadians(230))
                .stopAndAdd(() -> new AutoSampleDrop(arm, lifter))
                .strafeToLinearHeading(new Vector2d(-58, -48), Math.toRadians(225))
                .afterTime(0.2, () -> robot.Shoulder.setPosition(0.3533))

                .strafeToLinearHeading(new Vector2d(-50, -48), Math.toRadians(90))
                .afterTime(0.2, () -> lifter.updateLifterStatee(Lifter.LifterStatee.HOME))

                .waitSeconds(0.2)

                // first sample pick
                .strafeToLinearHeading(new Vector2d(-46, -37.5), Math.toRadians(90))
                .stopAndAdd(() -> new AutoSamplePick(arm, lifter))

                //sample drop
                .strafeToLinearHeading(new Vector2d(-60, -53), Math.toRadians(230))
                .stopAndAdd(() -> new AutoSampleDrop(arm, lifter))
                .strafeToLinearHeading(new Vector2d(-50, -48), Math.toRadians(90))

                .build();


        if (opModeInInit())
        {
            telemetry.addLine("Init");
            Actions.runBlocking(new SequentialAction(
                    new InstantAction(() -> new AutoInitSeq(arm, lifter)),
                    new InstantAction(()-> robot.Claw.setPosition(Globals.ClawOpen)),
                    new SleepAction(2),
                    new InstantAction(()-> robot.Claw.setPosition(Globals.ClawClose))
            ));
        }



        waitForStart();

        Actions.runBlocking(new SequentialAction(
                trajectoryAction0
        ));


    }
}

